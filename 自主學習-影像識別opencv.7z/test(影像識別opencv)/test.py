#印出串列及版本----------------
# import numpy as np
# arr = np.array([1, 2, 3, 4, 5])
# print(arr)
# print(type(arr))
# print(np.__version__)
#------------------------------

#做簡單折線圖--------------
# import matplotlib.pyplot as plt
# import seaborn as sns
# sns.distplot([0, 1, 2, 3, 4, 5,8,9,1,2], hist=False)
# plt.show()
#---------------------------

#製作長條圖--------------------
# from numpy import random
# import matplotlib.pyplot as plt
# import seaborn as sns
# sns.distplot(random.binomial(n=10, p=0.5, size=1000), hist=True, kde=False)
# plt.show()
#-------------------------------

#常態分佈與二元分佈的差別---------
# from numpy import random
# import matplotlib.pyplot as plt
# import seaborn as sns

# sns.distplot(random.normal(loc=50, scale=5, size=1000), hist=False, label='normal')
# sns.distplot(random.binomial(n=100, p=0.5, size=1000), hist=False, label='binomial')

# plt.show()
#---------------------------------

#相加兩陣列相對應的值
# x = [1, 2, 3, 4]
# y = [4, 5, 6, 7]
# z = []

# for i, j in zip(x, y):
#   z.append(i + j)
# print(z)
# ---------------------

#用numpy的方式相加陣列中相對應的值
# import numpy as np

# x = [1, 2, 3, 4]
# y = [4, 5, 6, 7]
# z = np.add(x, y)

# print(z)
#-----------------------------
