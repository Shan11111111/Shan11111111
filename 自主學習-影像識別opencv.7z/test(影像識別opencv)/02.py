import cv2
import numpy as np
img =cv2.imread("../test/flower.jpg",cv2.IMREAD_COLOR)

#RESIZE
img=cv2.resize(img(200,100))
img =cv2.resize(img,(0,0),fx=2,fy=1)
#CROP

#ROTATE

#TEANSLATE


cv2.imshow("flower!", img)
cv2.waitKey(0)
cv2.destroyAllWindows()