import cv2

img = cv2.imread("../test/flower.jpg",cv2.IMREAD_COLOR)
# print(img.shape)
# print(img[0,0])
# rgb_img=cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
# print(rgb_img[0,0])

# for i in range(img.shape[0]):
#     for j in range(img.shape[1]):
#         img[i,j] =max(40,img[i,j] *2)

cv2.imshow("Flower",img)
cv2.waitKey(0)
cv2.destroyAllWindows()

gray_img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imwrite("../test/flower.jpg",gray_img)

