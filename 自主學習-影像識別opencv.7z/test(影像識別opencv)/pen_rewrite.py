import cv2
import numpy as np

# 讀取畫面
cap = cv2.VideoCapture(1)

# 其他顏色偵測加入(藍、紫、黃)
penColorHSV = [
    [45,83,0,155,255,238],   # 藍
    [120, 25, 130, 138, 255, 255], # 紫
    [23, 62, 0, 35, 255, 238]      # 黃
]

penColorBGR = [
    [255, 0, 0],     # 綠
    [255, 0, 255],   # 紫
    [0, 255, 255]    # 黃
]

# [x, y, colorID]
drawPoints = []

def findPen(img, imgContour):
    """ 偵測畫面中的筆，並標記其位置 """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    for i in range(len(penColorHSV)):
        # 過濾顏色 (套上 mask 遮罩)
        lower = np.array(penColorHSV[i][:3])
        upper = np.array(penColorHSV[i][3:6])
        mask = cv2.inRange(hsv, lower, upper)

        # 找到筆的輪廓
        penx, peny = findContour(mask)
        if peny != -1:
            drawPoints.append([penx, peny, i])
            cv2.circle(imgContour, (penx, peny), 10, penColorBGR[i], cv2.FILLED)

def findContour(img):
    """ 找到筆的輪廓，並回傳其中心點 """
    contours, _ = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    x, y, w, h = -1, -1, -1, -1
    max_area = 0

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 500 and area > max_area:
            max_area = area
            peri = cv2.arcLength(cnt, True)
            vertices = cv2.approxPolyDP(cnt, peri * 0.02, True)
            x, y, w, h = cv2.boundingRect(vertices)

    return x + w // 2, y

def draw(imgContour):
    """ 在畫面上畫出偵測到的筆跡 """
    for point in drawPoints:
        cv2.circle(imgContour, (point[0], point[1]), 10, penColorBGR[point[2]], cv2.FILLED)

while True:
    ret, frame = cap.read()
    if ret:
        imgContour = frame.copy()
        
        # 偵測筆
        findPen(frame, imgContour)
        
        # 畫筆跡
        draw(imgContour)

        # 顯示畫面
        cv2.imshow('video', frame)
        cv2.imshow('contour', imgContour)

    else:
        break

    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
