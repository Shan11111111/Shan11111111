import cv2

img = cv2.imread('face02.jpg')
# 圖片轉換灰階
gray=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# 查opencv github找訓練好的模型 (資料夾路徑: opencv/data/haarcascades/haarcascade_frontalface_default.xml)
faceCascade = cv2.CascadeClassifier('face_detect.xml')

#矩形框框(第三個參數是框幾次:嚴謹的偵測，但也可能因為參數過大而無法框出來臉)
faceRect=faceCascade.detectMultiScale(gray,1.1,3)

for(x,y,w,h) in faceRect:
    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)

cv2.imshow('img',img)
cv2.waitKey(0)