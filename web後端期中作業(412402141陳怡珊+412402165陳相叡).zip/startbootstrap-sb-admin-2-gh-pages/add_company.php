<?php
// add_company.php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_name = $_POST['company_name'];
    $contact_person = $_POST['contact_person'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $sql = "INSERT INTO internship_companies (company_name, contact_person, address, phone, email) VALUES (:company_name, :contact_person, :address, :phone, :email)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':company_name' => $company_name,
        ':contact_person' => $contact_person,
        ':address' => $address,
        ':phone' => $phone,
        ':email' => $email
    ]);

    header("Location: company_list.php");
    exit();
}
?>