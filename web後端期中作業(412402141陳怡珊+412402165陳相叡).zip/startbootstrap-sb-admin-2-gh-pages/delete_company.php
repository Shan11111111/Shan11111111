<?php
// delete_company.php
include 'db.php';

$id = $_GET['id'];
$sql = "DELETE FROM internship_companies WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id]);

header("Location: company_list.php");
exit();
?>
