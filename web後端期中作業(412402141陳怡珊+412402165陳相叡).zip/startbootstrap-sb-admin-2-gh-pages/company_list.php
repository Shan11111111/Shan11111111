<?php
// company_list.php
include 'db.php';

$sql = "SELECT * FROM internship_companies";
$stmt = $pdo->query($sql);
$companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>實習企業列表</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .btn-add {
            display: inline-block;
            padding: 10px;
            background-color: #28a745;
            color: white;
            text-align: center;
            border-radius: 4px;
            text-decoration: none;
            margin-bottom: 20px;
        }

        .btn-add:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .actions a {
            color: #007BFF;
            text-decoration: none;
            margin-right: 10px;
        }

        .actions a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>實習企業列表</h1>
        <a class="btn-add" href="add_company.html">新增實習企業</a>
        <table>
            <tr>
                <th>企業名稱</th>
                <th>聯絡人</th>
                <th>地址</th>
                <th>電話</th>
                <th>Email</th>
                <th>操作</th>
            </tr>
            <?php foreach ($companies as $company): ?>
                <tr>
                    <td><?php echo htmlspecialchars($company['company_name']); ?></td>
                    <td><?php echo htmlspecialchars($company['contact_person']); ?></td>
                    <td><?php echo htmlspecialchars($company['address']); ?></td>
                    <td><?php echo htmlspecialchars($company['phone']); ?></td>
                    <td><?php echo htmlspecialchars($company['email']); ?></td>
                    <td class="actions">
                        <a href="edit_company.php?id=<?php echo $company['id']; ?>">編輯</a>
                        <a href="delete_company.php?id=<?php echo $company['id']; ?>"
                            onclick="return confirm('確定要刪除嗎？');">刪除</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>

</html>