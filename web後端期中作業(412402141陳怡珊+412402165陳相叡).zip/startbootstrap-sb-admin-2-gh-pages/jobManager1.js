// jobManager.js
const jobForm = document.getElementById('jobForm');
const jobList = document.getElementById('jobList');
let jobs = [
    {
        jobTitle: "前端工程師",
        companyName: "XYZ科技公司",
        location: "台北",
        jobDescription: "負責網站的前端開發，使用HTML、CSS和JavaScript。",
        internRequirements: "具備基本的HTML/CSS知識，對JavaScript有興趣。",
        salary: "月薪 40,000元",
        tags: ["前端", "全職"]
    },
    {
        jobTitle: "資料分析師",
        companyName: "ABC數據有限公司",
        location: "台中",
        jobDescription: "負責數據收集與分析，提供數據報告。",
        internRequirements: "熟悉Excel，具備數據分析能力。",
        salary: "月薪 38,000元",
        tags: ["分析", "實習"]
    },
    {
        jobTitle: "UI/UX設計師",
        companyName: "創意設計工作室",
        location: "台北",
        jobDescription: "設計使用者介面與使用者體驗，提升產品可用性。",
        internRequirements: "具備基本的設計軟體使用經驗，如Photoshop或Sketch。",
        salary: "月薪 45,000元",
        tags: ["設計", "全職"]
    },
    {
        jobTitle: "系統工程師",
        companyName: "123科技有限公司",
        location: "高雄",
        jobDescription: "負責系統架構設計與實作，確保系統穩定運行。",
        internRequirements: "具備基本的程式設計能力，熟悉Linux系統。",
        salary: "月薪 50,000元",
        tags: ["系統", "全職"]
    },
    {
        jobTitle: "行銷專員",
        companyName: "行銷集團",
        location: "台北",
        jobDescription: "負責行銷企劃與推廣活動，提升品牌知名度。",
        internRequirements: "對行銷有興趣，具備創意發想能力。",
        salary: "月薪 36,000元",
        tags: ["行銷", "實習"]
    },
    {
        jobTitle: "後端工程師",
        companyName: "雲端科技",
        location: "新北市",
        jobDescription: "負責伺服器端的開發，處理資料庫與API設計。",
        internRequirements: "熟悉Node.js或Python，有資料庫經驗。",
        salary: "月薪 48,000元",
        tags: ["後端", "全職"]
    },
    {
        jobTitle: "產品經理",
        companyName: "科技創新公司",
        location: "台南",
        jobDescription: "負責產品規劃與管理，確保產品符合市場需求。",
        internRequirements: "具備專案管理經驗，有良好的溝通能力。",
        salary: "月薪 55,000元",
        tags: ["產品", "全職"]
    },
    {
        jobTitle: "網頁設計師",
        companyName: "創意工作室",
        location: "台中",
        jobDescription: "負責網站的視覺設計與使用者體驗優化。",
        internRequirements: "熟悉HTML/CSS，有設計經驗者佳。",
        salary: "月薪 42,000元",
        tags: ["設計", "全職"]
    }
];

// 顯示職缺
function displayJobs() {
    jobList.innerHTML = '';
    jobs.forEach((job, index) => {
        const jobItem = document.createElement('li');
        jobItem.innerHTML = `
            <strong>${job.jobTitle}</strong>
            <div>公司名稱：${job.companyName}</div>
            <div>地點：${job.location}</div>
            <div>工作介紹：${job.jobDescription}</div>
            <div>實習生條件：${job.internRequirements}</div>
            <div>報酬：${job.salary}</div>
            <div class="tags">標籤：${job.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}</div>
            <button onclick="editJob(${index})">編輯</button>
            <button onclick="deleteJob(${index})">刪除</button>
            <hr>
        `;
        jobList.appendChild(jobItem);
    });
}

// 新增或編輯職缺
jobForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const jobId = document.getElementById('jobId').value;
    const jobTitle = document.getElementById('jobTitle').value;
    const companyName = document.getElementById('companyName').value;
    const location = document.getElementById('location').value;
    const jobDescription = document.getElementById('jobDescription').value;
    const internRequirements = document.getElementById('internRequirements').value;
    const salary = document.getElementById('salary').value;
    const tags = document.getElementById('tags').value.split(',').map(tag => tag.trim());

    if (jobId) {
        jobs[jobId] = { jobTitle, companyName, location, jobDescription, internRequirements, salary, tags };
    } else {
        jobs.push({ jobTitle, companyName, location, jobDescription, internRequirements, salary, tags });
    }

    jobForm.reset();
    displayJobs();
});

// 編輯職缺
function editJob(index) {
    const job = jobs[index];
    document.getElementById('jobId').value = index;
    document.getElementById('jobTitle').value = job.jobTitle;
    document.getElementById('companyName').value = job.companyName;
    document.getElementById('location').value = job.location;
    document.getElementById('jobDescription').value = job.jobDescription;
    document.getElementById('internRequirements').value = job.internRequirements;
    document.getElementById('salary').value = job.salary;
    document.getElementById('tags').value = job.tags.join(', ');
}

// 刪除職缺
function deleteJob(index) {
    jobs.splice(index, 1);
    displayJobs();
}

// 初始化顯示職缺
displayJobs();
