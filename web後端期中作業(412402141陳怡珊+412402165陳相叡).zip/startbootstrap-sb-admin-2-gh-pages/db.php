<?php
// db.php

$host = 'localhost';
$dbname = 'my_database';
$username = 'local';
$password = 'sandra940222';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "資料庫連接失敗：" . $e->getMessage();
    exit();
}
?>
