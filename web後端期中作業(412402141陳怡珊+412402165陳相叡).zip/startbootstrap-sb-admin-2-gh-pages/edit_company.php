<?php
// edit_company.php
include 'db.php';

$id = $_GET['id'];
$sql = "SELECT * FROM internship_companies WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>編輯實習企業</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            width: 100%;
            max-width: 400px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
        }
        input[type="text"], input[type="email"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        button {
            padding: 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>編輯實習企業</h1>
        <form action="update_company.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $company['id']; ?>">

            <label for="company_name">企業名稱</label>
            <input type="text" id="company_name" name="company_name" value="<?php echo htmlspecialchars($company['company_name']); ?>" required>

            <label for="contact_person">聯絡人</label>
            <input type="text" id="contact_person" name="contact_person" value="<?php echo htmlspecialchars($company['contact_person']); ?>">

            <label for="address">地址</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($company['address']); ?>">

            <label for="phone">電話</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($company['phone']); ?>">

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($company['email']); ?>">

            <button type="submit">更新企業</button>
        </form>
    </div>
</body>
</html>
